Log z jazdy: OpenRailsLog.txt w tym katalogu.
